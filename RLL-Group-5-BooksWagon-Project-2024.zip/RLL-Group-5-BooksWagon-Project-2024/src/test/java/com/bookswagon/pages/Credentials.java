package com.bookswagon.pages;


public class Credentials {

	private String Email="vetriselvan4949@gmail.com";
	private String Password="Jaya@111";
	private String MobileNumber="9994941492";
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public String getMobileNumber() {
		return MobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		MobileNumber = mobileNumber;
	}
	
}

